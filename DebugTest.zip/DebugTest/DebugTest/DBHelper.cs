﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebugTest
{
    public static class DBHelper
    {
        public static DateTime? TryGetValue(object obj, out DateTime? d)
        {
            if (obj != null && DateTime.TryParse(obj.ToString(), out DateTime date))
            {
                d = date;

            }
            d = null;
            return null;
        }

        public static string TryGetValue(object obj, out string s)
        {
            string value = null;
            if (obj != null)
            {
                value = obj.ToString();
            }

            s = value;
            return value;
        }
    }
}
