﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DebugTest
{
    public static class SSNValidationHelper
    {
        private static string _connection = @"Data Source=DESKTOP-S2M3GHO\SQLEXPRESS;Initial Catalog=AdventureWorks;Integrated Security=True";
        public static List<Patient> ValidateSsns(int batchSize)
        {
            var ssns = SelectPatientSsns(batchSize);
            var dtos = ValidateSsns(ssns);
            SaveSsnResults(dtos);

            return ssns;
        }

        private static void SaveSsnResults(List<Patient> patients)
        {
            foreach (var item in patients)
            {
                var connection = new SqlConnection(_connection);

                using (connection)
                {
                    SqlCommand sqlCommand = new SqlCommand("spSaveSsnResults", connection);
                    sqlCommand.Parameters.AddWithValue("@ssn", item.SSN);
                    sqlCommand.Parameters.AddWithValue("@isValid", item.IsValid);
                    sqlCommand.Parameters.AddWithValue("@firstName", item.FirstName);
                    sqlCommand.Parameters.AddWithValue("@lastName", item.LastName);
                    sqlCommand.Parameters.AddWithValue("@dob", item.DOB);

                    sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    connection.Open();
                    sqlCommand.ExecuteNonQuery();
                   }

                    

            }
        }

        private static List<Patient> ValidateSsns(List<Patient> patients)
        {

            foreach (var p in patients)
            {
                bool isValid = true;

                if (p.SSN.Length < 9)
                {
                    isValid = false;
                }

                p.IsValid = isValid;
            }
            return patients;
        }

        public static List<Patient> SelectPatientSsns(int batchSize)
        {
            List<Patient> patients = new List<Patient>();

            var connection = new SqlConnection(_connection);

            using (connection)
            {
                SqlCommand sqlCommand = new SqlCommand("spSelectPatients", connection);
                sqlCommand.Parameters.AddWithValue("@batchSize", batchSize);

                sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;

                connection.Open();

                SqlDataReader reader = sqlCommand.ExecuteReader();

                while (reader.Read())
                {
                    Patient current = new Patient();
                    current.FirstName = DBHelper.TryGetValue(reader["FirstName"], out string firstName);
                    current.LastName = DBHelper.TryGetValue(reader["LastName"], out string lastName);
                    current.DOB = DBHelper.TryGetValue(reader["DOB"], out DateTime? DOB);
                    current.SSN = DBHelper.TryGetValue(reader["Ssn"], out string ssn);
                    patients.Add(current);
                }

                return patients;
            }
        }

        public class Patient
        {
            public string FirstName { get; set; }

            public string LastName { get; set; }
            public string SSN { get; set; }

            public DateTime? DOB { get; set; }
            public bool IsValid { get; set; }
        }
    }
}
